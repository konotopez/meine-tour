1. Загрузить проект в GitHub.
2. Открыть вкладку Actions.
3. Запустить workflow: Build Android APK.
4. После сборки открыть Artifacts.
5. Скачать архив meine-tour-apk.
6. Внутри будет готовый APK.

Имя приложения: Meine Tour
Пакет: com.meinetour.app
