Meine Tour - Android Studio project

Что внутри:
- app/src/main/assets/index.html  -> ваш HTML
- WebView приложение, которое открывает локальный HTML
- JavaScript и localStorage включены
- внешние ссылки и Google Maps открываются через Android

Как собрать APK:
1. Откройте папку meine_tour_project в Android Studio.
2. Дождитесь Gradle Sync.
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. Готовый APK появится в app/build/outputs/apk/debug/

Пакет приложения:
com.meinetour.app
